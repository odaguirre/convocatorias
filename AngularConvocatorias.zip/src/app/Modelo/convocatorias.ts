import { ServiceService } from 'src/app/Service/service.service';

export class convocatorias {
    _id?: string;
    nombre?: String;
    fecha_inicio?: Date;
    fecha_fin?: Date;
    acta?: Number;
    estado?: Boolean;
/*
    constructor(nombre: String, fecha_inicio: Date, fecha_fin: Date, acta: Number, estado: Boolean) {
        this.nombre = nombre;
        this.fecha_inicio = fecha_inicio;
        this.fecha_fin = fecha_fin;
        this.acta = acta;
        this.estado = estado;
    }

    getConvocatorias() {
        return this.http.get<convocatorias[]>(this.url);
    }
    getConvocatoria(id: number) {
        return this.http.get<convocatorias>(this.url + '/' + id);
    }

    createConvocatoria(convocatoria: convocatorias) {
        return this.http.post<convocatorias>(this.url, convocatoria);
    }

    updateConvocatoria(convocatoria: convocatorias) {
        return this.http.put<convocatorias>(this.url + '/' + convocatoria.id, convocatoria);
    }

    deleteConvocatoria(id: number) {
        return this.http.delete<convocatorias>(this.url + '/' + id);
    }*/
}

